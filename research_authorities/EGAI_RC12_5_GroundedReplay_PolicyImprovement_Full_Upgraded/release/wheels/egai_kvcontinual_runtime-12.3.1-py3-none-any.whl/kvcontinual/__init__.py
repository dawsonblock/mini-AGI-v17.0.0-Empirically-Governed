"""RC12.3.1 Target-Mac qualification canonical Python namespace.

The runtime is one distribution with two explicit validity domains:
- kvcontinual.continual: experience, memory, adapters, learning.
- kvcontinual.execution: execution artifacts, hybrid reconstruction, qualification, authority.

No top-level module is silently shadowed by another package.
"""
__version__ = "12.3.1"
